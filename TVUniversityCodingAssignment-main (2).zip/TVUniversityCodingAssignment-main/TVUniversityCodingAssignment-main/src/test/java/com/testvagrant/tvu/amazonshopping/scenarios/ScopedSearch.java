package com.testvagrant.tvu.amazonshopping.scenarios;

import org.testng.annotations.Test;

import com.testvagrant.tvu.amazonshopping.components.SearchCategory;
import com.testvagrant.tvu.amazonshopping.components.SearchComponent;
import com.testvagrant.tvu.amazonshopping.data.SearchData;
import com.testvagrant.tvu.amazonshopping.models.SearchContext;

public class ScopedSearch extends BaseScenario{
	

    @Test(groups = "smoke",  dataProvider = "search_items", dataProviderClass = SearchData.class)
    public void customerScopeSearch(SearchContext searchContext) {
        SearchCategory searchCategory = getComponent(SearchCategory.class);
        		searchCategory.categorySearchAndSelect();
        		SearchComponent searchComponent = getComponent(SearchComponent.class);
                searchComponent.customerSearch(searchContext);
                searchCategory.verifyCategoryName();
                searchCategory.verifyItemsName();
                searchCategory.verifyItemName();
    }
}
