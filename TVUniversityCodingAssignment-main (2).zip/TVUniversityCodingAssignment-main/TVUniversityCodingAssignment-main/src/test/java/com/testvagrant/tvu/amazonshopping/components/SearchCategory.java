package com.testvagrant.tvu.amazonshopping.components;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.testvagrant.tvu.amazonshopping.models.Item;
import com.testvagrant.tvu.amazonshopping.models.SearchContext;
import com.testvagrant.tvu.amazonshopping.pages.BaseComponent;

public class SearchCategory  extends BaseComponent {
	
	@FindBy(id = "searchDropdownBox")
     WebElement searchBox;

    @FindBy(xpath = "//*[@id=\"search\"]/span/div/span/h1/div/div[1]/div/div/span[3]")
    private WebElement searchedItems;
    
    @FindBy(xpath = "//*[@id=\"search\"]/div[1]/div[2]/div/span[3]/div[2]")
    private WebElement listOfElements;

    public void categorySearchAndSelect() {
        Select drpCategory = new Select(searchBox);
        drpCategory.selectByVisibleText("Grocery & Gourmet Foods");
    }
    
    public boolean verifyCategoryName() {
    	Select drpCategory = new Select(searchBox);
    	String selectedValue = drpCategory.getFirstSelectedOption().getText();
    	if(selectedValue.equals("All"));
    	return true;
    }

    public boolean verifyItemsName() {
    	String selectedItem = searchedItems.getText();
    	System.out.print(searchedItems.getText());
    	if(selectedItem.equals("Car"));
    	return true;
    }

    public boolean verifyItemName() {
    	String selectedItem = listOfElements.getText();
    	System.out.print(listOfElements.getText());
    	if(selectedItem.toString().contains("Famous Quality� Full Channel 1:24 Remote Control Car, RC Car, Super Racing car with LED Head Light (3+Age, (Color and Design be My Very)"));
    	return true;
    }
}
