package com.testvagrant.tvu.amazonshopping.drivers;

public enum Browser {
    CHROME,
    FIREFOX,
    SAFARI, //skipping implementation for demo
    EDGE //skipping implementation for demo
}
