package com.testvagrant.tvu.amazonshopping.pages;

public class BaseComponent extends BasePage<BaseComponent> {

    @Override
    public BaseComponent init(BaseComponent page) {
        return super.init(page);
    }

}
