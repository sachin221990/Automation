package com.testvagrant.tvu.amazonshopping.drivers;

public enum Target {
    UI,
    HEADLESS
}
